package com.example.posttest2_139_fanny

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
