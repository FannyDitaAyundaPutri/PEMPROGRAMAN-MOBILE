import 'package:flutter/material.dart';

const kBackgroundColor = Color(0xFFFFFFFF);
const kPrimaryColor = Color(0xFFFFBD73);