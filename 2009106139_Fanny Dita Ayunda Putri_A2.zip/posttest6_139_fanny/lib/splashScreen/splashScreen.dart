import 'package:animated_splash_screen/animated_splash_screen.dart';
import 'package:cupcake_app/Login/login.dart';
import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';

class splashScreen extends StatelessWidget {
  const splashScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return AnimatedSplashScreen(
      splash: Container(
        padding: EdgeInsets.fromLTRB(30.0, 60.0, 30.0, 0.0),
        child: Image(
          image: AssetImage('assets/images/logoFanny.png'),
        ),
      ),
      splashIconSize: 700,
      duration: 3000,
      splashTransition: SplashTransition.slideTransition,
      backgroundColor: Color.fromARGB(255, 255, 222, 89),
      pageTransitionType: PageTransitionType.rightToLeft,
      nextScreen: const login(),
    );
  }
}
