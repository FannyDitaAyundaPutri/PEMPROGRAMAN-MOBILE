import 'package:cupcake_app/Login/login.dart';
import 'package:cupcake_app/homePage/home.dart';
import 'package:favorite_button/favorite_button.dart';
import 'package:flutter/material.dart';
import 'package:readmore/readmore.dart';

List<User> user = [];

class User {
  //modal class for Person object
  String id, nama, desc, author;
  User({
    required this.id,
    required this.nama,
    required this.desc,
    required this.author,
    // required this.type
  });
}

class beranda extends StatefulWidget {
  const beranda({super.key});

  @override
  State<beranda> createState() => _berandaState();
}

class _berandaState extends State<beranda> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Container(
          color: Colors.amber.shade200,
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          padding: const EdgeInsets.all(10),
          child: Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height,
            child: Column(
              mainAxisSize: MainAxisSize.max,
              children: user.map((personone) {
                return Card(
                  child: SizedBox(
                    child: ListTile(
                      title: Center(
                          child: Text(
                        personone.nama,
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 14),
                      )),
                      subtitle: ReadMoreText(
                        "\nAuthor :  ${personone.author}\n\n${personone.desc}",
                        trimLines: 5,
                        colorClickableText: Colors.pink,
                        trimMode: TrimMode.Line,
                        trimCollapsedText: '  Selengkapnya...',
                        trimExpandedText: ' Persingkat...',
                        textAlign: TextAlign.justify,
                      ),
                      trailing: FavoriteButton(
                        iconSize: 30,
                        isFavorite: false,
                        // iconDisabledColor: Colors.white,
                        valueChanged: (_isFavorite) {
                          print('Is Favorite : $_isFavorite');
                        },
                      ),
                    ),
                  ),
                );
              }).toList(growable: false),
            ),
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.purple.shade200,
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (_) {
              return tambah_item();
            }),
          );
        },
        child: const Icon(
          Icons.add,
          color: Colors.white,
        ),
      ),
    );
  }
}

class tambah_item extends StatefulWidget {
  const tambah_item({super.key});

  @override
  State<tambah_item> createState() => _addState();
}

class _addState extends State<tambah_item> {
  String nama = '';
  String desc = '';
  String author = '';

  final ctrlNama = TextEditingController();
  final ctrlAuthor = TextEditingController();
  final ctrlDesc = TextEditingController();

//ADD AN ITEM
  Widget Nama() {
    return TextFormField(
      maxLines: 1,
      controller: ctrlNama,
      decoration: InputDecoration(
        hintText: "Judul",
        prefixIcon: const Icon(Icons.title),
        hintStyle: TextStyle(
          color: Colors.black.withOpacity(0.5),
          fontWeight: FontWeight.w400,
          fontStyle: FontStyle.normal,
        ),
        fillColor: Colors.white.withOpacity(0.3),
        filled: true,
      ),
    );
  }

  Widget Author() {
    return TextFormField(
      maxLines: 1,
      controller: ctrlAuthor,
      decoration: InputDecoration(
        hintText: "Author",
        prefixIcon: const Icon(Icons.person),
        hintStyle: TextStyle(
          color: Colors.black.withOpacity(0.5),
          fontWeight: FontWeight.w400,
          fontStyle: FontStyle.normal,
        ),
        fillColor: Colors.white.withOpacity(0.3),
        filled: true,
      ),
    );
  }

  Widget describe() {
    return TextFormField(
      maxLines: 5,
      controller: ctrlDesc,
      decoration: InputDecoration(
        hintText: "Deskripsi",
        prefixIcon: const Icon(Icons.description),
        hintStyle: TextStyle(
          color: Colors.black.withOpacity(0.5),
          fontWeight: FontWeight.w400,
          fontStyle: FontStyle.normal,
        ),
        fillColor: Colors.white.withOpacity(0.3),
        filled: true,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actions: [
          Row(
            children: [
              Container(
                margin: EdgeInsets.only(right: 10),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(
                      'Hallo, ',
                      style: TextStyle(
                        color: Colors.black,
                        fontFamily: 'Atma',
                        fontSize: 12,
                      ),
                    ),
                    Text(
                      ' Fanny  ',
                      style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: Colors.black,
                          fontFamily: "Montserrat",
                          fontSize: 10),
                    ),
                  ],
                ),
              ),
              Container(
                padding: EdgeInsets.only(right: 10),
                child: CircleAvatar(
                  backgroundImage: AssetImage('Images/fannyprofile.jpg'),
                  radius: 20,
                ),
              ),
            ],
          ),
        ],
        backgroundColor: Colors.amber,
        title: const Text(
          'Pet Cat',
          style: TextStyle(color: Colors.black, fontFamily: 'Acme'),
        ),
      ),
      body: ListView(
        scrollDirection: Axis.vertical,
        children: [
          Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height,
            decoration: BoxDecoration(
              color: Colors.amber.shade50,
              image: DecorationImage(
                colorFilter: ColorFilter.mode(
                    Colors.white.withOpacity(0.09), BlendMode.dstATop),
                image: const AssetImage('Images/petshop_logo.png'),
                fit: BoxFit.contain,
              ),
            ),
            child: Column(
              children: [
                Container(
                  margin: const EdgeInsets.fromLTRB(30, 20, 30, 0),
                  child: Column(
                    children: [
                      const Text(
                        'Judul',
                        style: TextStyle(
                          fontSize: 18,
                          fontFamily: 'Acme',
                          fontWeight: FontWeight.w900,
                          color: Colors.black,
                        ),
                        textAlign: TextAlign.justify,
                      ),
                      Nama(),
                    ],
                  ),
                ),
                Container(
                  margin: const EdgeInsets.fromLTRB(30, 20, 30, 0),
                  child: Column(
                    children: [
                      const Text(
                        'Author',
                        style: TextStyle(
                          fontSize: 18,
                          fontFamily: 'Acme',
                          fontWeight: FontWeight.w900,
                          color: Colors.black,
                        ),
                        textAlign: TextAlign.justify,
                      ),
                      Author(),
                    ],
                  ),
                ),
                Container(
                  margin: const EdgeInsets.fromLTRB(30, 20, 30, 0),
                  child: Column(
                    children: [
                      const Text(
                        'Deskripsi',
                        style: TextStyle(
                          fontSize: 18,
                          fontFamily: 'Acme',
                          fontWeight: FontWeight.w900,
                          color: Colors.black,
                        ),
                        textAlign: TextAlign.justify,
                      ),
                      describe(),
                    ],
                  ),
                ),
                Container(
                  margin: const EdgeInsets.fromLTRB(30, 20, 30, 0),
                  width: 315,
                  height: 45,
                  child: ElevatedButton(
                    // tombol order
                    onPressed: () {
                      setState(() {
                        int panjang = user.length;
                        nama = ctrlNama.text;
                        author = ctrlAuthor.text;
                        desc = ctrlDesc.text;
                        user.add(User(
                          id: "$panjang",
                          nama: nama,
                          author: author,
                          desc: desc,
                        ));
                      });
                      final snackBar = SnackBar(
                        content:
                            const Text('Resep anda berhasil ditambahkan !'),
                      );
                      ScaffoldMessenger.of(context).showSnackBar(snackBar);
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (_) {
                          return const home();
                        }),
                      );
                    },
                    style: TextButton.styleFrom(
                        backgroundColor: Colors.amber,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20))),
                    child: const Text(
                      "Tambah",
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 16,
                          fontFamily: 'RussoOne'),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
