import 'package:flutter/material.dart';

class profile extends StatefulWidget {
  const profile({super.key, required String email, required String password});

  @override
  State<profile> createState() => _profileState();
}

class _profileState extends State<profile> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        color: Colors.amber.shade200,
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        child: Column(
          children: const [
            Padding(
              padding: EdgeInsets.only(top: 40),
              child: CircleAvatar(
                backgroundImage: AssetImage('Images/fannyprofile.jpg'),
                radius: 80,
              ),
            ),
            Text(
              "Fanny Dita Ayunda Putri",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 20,
                fontFamily: "Acme",
                fontWeight: FontWeight.bold,
              ),
            ),
            Padding(
              padding: EdgeInsets.only(left: 30, right: 30),
              child: Text(
                "\nHalo, nama saya Fanny Dita Ayunda Putri. Saya seorang mahasiswa di Universitas Mulawarman jurusan Teknik Informatika. Saya sangat tertarik dengan teknologi dan senang belajar tentang pemrograman. Di waktu luang, saya suka membaca buku atau menonton film. Saya senang bergabung dengan komunitas pengembang perangkat lunak untuk terus meningkatkan kemampuan saya dalam bidang ini. Itu sedikit tentang diri saya, terima kasih.",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 14,
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}
